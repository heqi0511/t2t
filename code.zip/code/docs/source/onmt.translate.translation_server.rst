Server
======


Models
-------------

.. autoclass:: onmt.translate.translation_server.ServerModel
    :members:


Core Server
------------

.. autoexception:: onmt.translate.translation_server.ServerModelError

.. autoclass:: onmt.translate.translation_server.Timer
    :members:

.. autoclass:: onmt.translate.translation_server.TranslationServer
    :members:
