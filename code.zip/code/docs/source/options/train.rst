Train
=====

.. argparse::
    :filename: ../train.py
    :func: _get_parser
    :prog: train.py