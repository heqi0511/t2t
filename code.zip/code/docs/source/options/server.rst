Server
=========

.. argparse::
    :filename: ../server.py
    :func: _get_parser
    :prog: server.py