Translate
=========

.. argparse::
    :filename: ../translate.py
    :func: _get_parser
    :prog: translate.py